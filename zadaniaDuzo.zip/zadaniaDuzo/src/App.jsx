import { useState, useEffect, useRef, createContext, useContext } from "react";
import cat1 from "./assets/kot.jpg";
import cat2 from "./assets/kot2.jpg";
import cat3 from "./assets/kot3.jpg";
//Zadanie1
// Zmiana tytułu strony
function ChangeTitle() {
  const [title, setTitle] = useState("Moja strona");

  useEffect(() => {
    document.title = title;
  }, [title]);

  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 1: Zmiana tytułu strony</h2>
      <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} style={inputStyle}/>
    </div>
  );
}

//Zadanie2
// Licznik zwiększany co sekundę
function Counter() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setCount(prev => prev + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 2: Licznik co sekundę</h2>
      <p style={{color:"black"}}>Licznik: {count}</p>
      {count >= 10 && <p style={{color:"black"}}>Osiągnięto 10!</p>}
    </div>
  );
}

//Zadanie3
// Informacje o użytkowniku
const UserContext = createContext();
function UserInfo() {
  const user = useContext(UserContext);
  useEffect(() => { console.log(`Witaj, ${user.name}!`) }, [user]);
  return <p style={{color:"black"}}>Użytkownik: {user.name}, wiek: {user.age}</p>;
}
function Task3() {
  const user = { name: "Jan", age: 25 };
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 3: Informacje o użytkowniku</h2>
      <UserContext.Provider value={user}>
        <UserInfo />
      </UserContext.Provider>
    </div>
  );
}

//Zadanie4
// Formularz z kontekstem
const FormContext = createContext();
function FormInput() {
  const { formData, setFormData } = useContext(FormContext);
  return (
    <div>
      <input type="text" placeholder="Imię" value={formData.firstName} onChange={(e)=>setFormData({...formData, firstName:e.target.value})} style={inputStyle}/>
      <input type="text" placeholder="Nazwisko" value={formData.lastName} onChange={(e)=>setFormData({...formData, lastName:e.target.value})} style={inputStyle}/>
    </div>
  );
}
function FormDisplay() {
  const { formData } = useContext(FormContext);
  return <p style={{color:"black"}}>Dane formularza: {formData.firstName} {formData.lastName}</p>;
}
function Task4() {
  const [formData,setFormData] = useState({firstName:"", lastName:""});
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 4: Kontekst formularza</h2>
      <FormContext.Provider value={{formData,setFormData}}>
        <FormInput/>
        <FormDisplay/>
      </FormContext.Provider>
    </div>
  );
}

//Zadanie5
// Zmiana koloru tła
function ChangeColor() {
  const divRef = useRef();
  const [color,setColor] = useState("");
  const handleClick = ()=>{ if(divRef.current) divRef.current.style.backgroundColor=color }
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 5: Zmiana koloru tła</h2>
      <input type="text" value={color} onChange={(e)=>setColor(e.target.value)} placeholder="Wpisz kolor" style={inputStyle}/>
      <button onClick={handleClick} style={buttonStyle}>Zmień kolor</button>
      <div ref={divRef} style={{width:"200px",height:"100px",margin:"10px auto",border:"1px solid #ccc"}}></div>
    </div>
  );
}

//Zadanie6
// Przeglądarka zdjęć
function Gallery() {
  const images = [cat1, cat2, cat3];
  const [index,setIndex] = useState(0);
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 6: Przeglądarka zdjęć</h2>
      <img src={images[index]} alt="gallery" style={{display:"block",margin:"10px auto"}}/>
      <div style={{textAlign:"center"}}>
        <button onClick={()=>setIndex((i)=>(i-1+images.length)%images.length)} style={buttonStyle}>Poprzednie</button>
        <button onClick={()=>setIndex((i)=>(i+1)%images.length)} style={buttonStyle}>Następne</button>
      </div>
    </div>
  );
}

//Zadanie7
// Gra w zgadywanie liczby
function GuessNumber() {
  const [number] = useState(() => Math.floor(Math.random() * 100) + 1);
  const [guess,setGuess]=useState("");
  const [message,setMessage]=useState("");
  const checkNumber = ()=>{
    const g=Number(guess);
    if(g===number) setMessage("Brawo! Trafiłeś!");
    else if(g<number) setMessage("Za mało");
    else setMessage("Za dużo");
  }
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 7: Gra w zgadywanie liczby</h2>
      <input type="number" value={guess} onChange={e=>setGuess(e.target.value)} style={inputStyle}/>
      <button onClick={checkNumber} style={buttonStyle}>Sprawdź</button>
      <p style={{color:"black"}}>{message}</p>
    </div>
  );
}

//Zadanie8
// Wyświetlanie aktualnej godziny
function Clock() {
  const [time,setTime]=useState(new Date());
  useEffect(()=>{ const interval=setInterval(()=>setTime(new Date()),1000); return ()=>clearInterval(interval)},[]);
  return (
    <div style={cardStyle}>
      <h2 style={{color:"black"}}>Zadanie 8: Wyświetlanie aktualnej godziny</h2>
      <p style={{color:"black"}}>{time.toLocaleTimeString()}</p>
    </div>
  );
}


const cardStyle = {
  background:"white",
  padding:"20px",
  borderRadius:"10px",
  boxShadow:"0 2px 8px rgba(0,0,0,0.2)",
  maxWidth:"500px",
  margin:"20px auto",
  textAlign:"center",
  color:"black" 
};
const inputStyle = { padding:"5px", margin:"5px", width:"80%" };
const buttonStyle = { padding:"5px 10px", margin:"5px", cursor:"pointer" };


export default function App(){
  const tasks = [
    {id:1,name:"Zadanie 1: Zmiana tytułu strony",component:<ChangeTitle/>},
    {id:2,name:"Zadanie 2: Licznik co sekundę",component:<Counter/>},
    {id:3,name:"Zadanie 3: Informacje o użytkowniku",component:<Task3/>},
    {id:4,name:"Zadanie 4: Kontekst formularza",component:<Task4/>},
    {id:5,name:"Zadanie 5: Zmiana koloru tła",component:<ChangeColor/>},
    {id:6,name:"Zadanie 6: Przeglądarka zdjęć",component:<Gallery/>},
    {id:7,name:"Zadanie 7: Gra w zgadywanie liczby",component:<GuessNumber/>},
    {id:8,name:"Zadanie 8: Wyświetlanie godziny",component:<Clock/>},
  ];

  const [selectedTask,setSelectedTask]=useState(1);

  return (
    <div style={{display:"flex",justifyContent:"center",alignItems:"center",minHeight:"100vh",background:"#2c2424ff",padding:"20px"}}>
      <div style={{width:"100%",maxWidth:"600px"}}>
        <div style={{textAlign:"center",marginBottom:"20px"}}>
          {tasks.map(task=>(
            <button 
              key={task.id} 
              onClick={()=>setSelectedTask(task.id)} 
              style={{
                ...buttonStyle,
                background:selectedTask===task.id?"#796464ff":"#fff",
                color:selectedTask===task.id?"white":"black",
                border:selectedTask===task.id?"none":"1px solid #000"
              }}
            >
              {task.name}
            </button>
          ))}
        </div>
        {tasks.find(t=>t.id===selectedTask)?.component}
      </div>
    </div>
  );
}
