import { useState } from "react";
import WorkoutItem from "./WorkoutItem.jsx";

export default function App() {
  const [workouts, setWorkouts] = useState([
    { id: 1, exercise: "Bieganie 🏃", calories: 200, category: "Cardio", completed: false },
    { id: 2, exercise: "Pompki 💪", calories: 50, category: "Strength", completed: true },
    { id: 3, exercise: "Przysiady 🏋️", calories: 80, category: "Strength", completed: false },
    { id: 4, exercise: "Plank 🤸", calories: 30, category: "Flexibility", completed: true },
    { id: 5, exercise: "Burpees 💥", calories: 120, category: "Cardio", completed: false },
    { id: 6, exercise: "Jazda na rowerze 🚴", calories: 150, category: "Cardio", completed: false }
  ]);

  const [categoryFilter, setCategoryFilter] = useState("all");

  const toggleComplete = (id) =>
    setWorkouts(workouts.map(w => w.id === id ? { ...w, completed: !w.completed } : w));

  const deleteWorkout = (id) =>
    setWorkouts(workouts.filter(w => w.id !== id));

  const updateCalories = (id, newCalories) =>
    setWorkouts(workouts.map(w => w.id === id ? { ...w, calories: newCalories } : w));

  const resetDay = () =>
    setWorkouts(workouts.filter(w => !w.completed));

  const completedCount = workouts.filter(w => w.completed).length;
  const doneCalories = workouts.filter(w => w.completed).reduce((s, w) => s + w.calories, 0);
  const totalCalories = workouts.reduce((s, w) => s + w.calories, 0);

  const filtered = workouts.filter(w =>
    categoryFilter === "all" ? true : w.category === categoryFilter
  );

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        background: "#2c2424ff",
        padding: "20px"
      }}
    >
      <div
        style={{
          width: "600px",
          padding: "20px",
          border: "1px solid #ddd",
          borderRadius: "10px",
          background: "#796464ff"
        }}
      >
        <h1 style={{ textAlign: "center" }}>🔥 Tracker treningów</h1>

        <p style={{ textAlign: "center" }}>
          Wykonane treningi: {completedCount} / {workouts.length}
        </p>

        <p style={{ textAlign: "center" }}>Kalorie wykonane: {doneCalories}</p>
        <p style={{ textAlign: "center" }}>Kalorie ogółem: {totalCalories}</p>

        <div style={{ textAlign: "center", marginBottom: "15px" }}>
          <button onClick={resetDay}>Reset dnia (usuń wykonane)</button>
        </div>

        <div style={{ marginBottom: "15px" }}>
          <strong>Kategoria: </strong>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="all">Wszystkie</option>
            <option value="Cardio">Cardio</option>
            <option value="Strength">Strength</option>
            <option value="Flexibility">Flexibility</option>
          </select>
        </div>

        <hr />

        {filtered.map((workout) => (
          <WorkoutItem
            key={workout.id}
            workout={workout}
            onToggleComplete={toggleComplete}
            onDelete={deleteWorkout}
            onUpdateCalories={updateCalories}
          />
        ))}
      </div>
    </div>
  );
}
