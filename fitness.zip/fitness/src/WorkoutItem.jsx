export default function WorkoutItem({
  workout,
  onToggleComplete,
  onDelete,
  onUpdateCalories
}) {
  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "8px",
        border: "1px solid #cccccc34",
        borderRadius: "6px",
        marginBottom: "6px",
        background: "white"
      }}
    >
      <div>
        <input
          type="checkbox"
          checked={workout.completed}
          onChange={() => onToggleComplete(workout.id)}
        />

        <span
          style={{
            marginLeft: "8px",
            textDecoration: workout.completed ? "line-through" : "none",
            color: workout.completed ? "gray" : "black"
          }}
        >
          {workout.exercise} — {workout.calories} kcal
        </span>

        {workout.completed && (
          <strong style={{ color: "green", marginLeft: "6px" }}>✅ DONE</strong>
        )}
      </div>

      <div>
        <button onClick={() => onUpdateCalories(workout.id, workout.calories + 10)}>
          +10
        </button>

        <button
          onClick={() =>
            onUpdateCalories(workout.id, Math.max(10, workout.calories - 10))
          }
          style={{ marginLeft: "5px" }}
        >
          -10
        </button>

        <button
          onClick={() => onDelete(workout.id)}
          style={{ marginLeft: "5px", color: "red" }}
        >
          Usuń
        </button>
      </div>
    </div>
  );
}
