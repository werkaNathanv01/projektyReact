import { useState } from "react";

function BookItem({ book, onToggleRead, onDelete, onUpdatePages }) {
  return (
    <div
      style={{
        display: "flex",
        gap: "10px",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "8px",
        border: "1px solid #cccccc34",
        borderRadius: "6px",
        marginBottom: "6px",
        background: "white"
      }}
    >
      <div>
        <input
          type="checkbox"
          checked={book.read}
          onChange={() => onToggleRead(book.id)}
        />

        <span
          style={{
            marginLeft: "8px",
            textDecoration: book.read ? "line-through" : "none",
            color: book.read ? "gray" : "black"
          }}
        >
          {book.title} — {book.pages} stron
        </span>
      </div>

      <div>
        <button onClick={() => onUpdatePages(book.id, book.pages + 50)}>
          +50
        </button>

        <button
          onClick={() =>
            onUpdatePages(book.id, Math.max(50, book.pages - 50))
          }
          style={{ marginLeft: "5px" }}
        >
          -50
        </button>

        <button
          onClick={() => onDelete(book.id)}
          style={{ marginLeft: "5px", color: "red" }}
        >
          Usuń
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [books, setBooks] = useState([
    { id: 1, title: "Harry Potter", pages: 350, read: false },
    { id: 2, title: "Władca Pierścieni", pages: 500, read: true },
    { id: 3, title: "Wiedźmin", pages: 300, read: false },
    { id: 4, title: "1984", pages: 250, read: true },
    { id: 5, title: "Hobbit", pages: 400, read: false },
  ]);

  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("none");

  const toggleRead = (id) =>
    setBooks((prev) =>
      prev.map((b) => (b.id === id ? { ...b, read: !b.read } : b))
    );

  const deleteBook = (id) =>
    setBooks((prev) => prev.filter((b) => b.id !== id));

  const updatePages = (id, newPages) =>
    setBooks((prev) =>
      prev.map((b) => (b.id === id ? { ...b, pages: newPages } : b))
    );

  const markAllAsRead = () =>
    setBooks((prev) => prev.map((b) => ({ ...b, read: true })));

  const filtered = books.filter((b) => {
    if (filter === "read") return b.read;
    if (filter === "unread") return !b.read;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sort === "asc") return a.pages - b.pages;
    if (sort === "desc") return b.pages - a.pages;
    return 0;
  });

  const readCount = books.filter((b) => b.read).length;
  const totalPages = books.reduce((sum, b) => sum + b.pages, 0);

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
        background: "#2c2424ff",
      }}
    >
      <div
        style={{
          width: "600px",
          padding: "20px",
          border: "1px solid #ddd",
          borderRadius: "10px",
          background: "#796464ff",
        }}
      >
        <h1 style={{ textAlign: "center" }}>📚 Biblioteka</h1>

        <p style={{ textAlign: "center", marginBottom: "4px" }}>
          Przeczytane: {readCount} / {books.length}
        </p>
        <p style={{ textAlign: "center" }}>Łącznie stron: {totalPages}</p>

        <div style={{ textAlign: "center", marginBottom: "15px" }}>
          <button onClick={markAllAsRead}>Przeczytaj wszystko</button>
        </div>

        <div style={{ marginBottom: "15px" }}>
          <strong>Filtrowanie: </strong>
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">Wszystkie</option>
            <option value="read">Przeczytane</option>
            <option value="unread">Nieprzeczytane</option>
          </select>
        </div>

        <div style={{ marginBottom: "15px" }}>
          <strong>Sortowanie: </strong>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="none">Brak</option>
            <option value="asc">Strony rosnąco</option>
            <option value="desc">Strony malejąco</option>
          </select>
        </div>

        <hr />

        {sorted.map((book) => (
          <BookItem
            key={book.id}
            book={book}
            onToggleRead={toggleRead}
            onDelete={deleteBook}
            onUpdatePages={updatePages}
          />
        ))}
      </div>
    </div>
  );
}
