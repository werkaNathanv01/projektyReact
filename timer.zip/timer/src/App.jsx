import React, {useState, useRef, useEffect} from "react";

const Timer = () =>{
    const [time, setTime] = useState(0)
    const [isActive, setIsActive] = useState(false)
    const [laps, setLaps] = useState([])
    const intervalRef = useRef(null);

    useEffect(()=>{
        if(isActive){
            intervalRef.current = setInterval(()=> setTime(prev => prev + 10), 10)
        }else{
            clearInterval(intervalRef.current);
        }
        return () => clearInterval(intervalRef.current);
    }, [isActive])
    
    const format = (ms) =>{
        const minutes = Math.floor(ms/60000)
        const seconds = Math.floor((ms % 60000) / 1000)
        const milliseconds = Math.floor((ms %1000)/ 10)

        const m = minutes < 10 ? "0" + minutes : minutes;
        const s = seconds < 10 ? "0" + seconds : seconds;
        const m1 = milliseconds < 10 ? "0" + milliseconds : milliseconds;

        return m + ":"+ s + ":" + m1
    }
    
    const handleStart = () =>{
        setIsActive(true)
    }
    const handleStop = () =>{
        setIsActive(false)
    }
    const handleReset = () =>{
        setIsActive(false);
        setTime(0)
        setLaps([])
    }
    const handleSave = () =>{
        setLaps(prev => [...prev, time])
    }
    const handleDelete = (index) =>{
        const newLaps = laps.filter((_, i) => i !== index)
        setLaps(newLaps)
    }

    return (
      <div>
        <h2>{format(time)}</h2>
        <div>
          {isActive ? (
            <button onClick={handleStop}>Stop</button>
          ) : (
            <button onClick={handleStart}>Start</button>
          )}

          <button onClick={handleReset}>Reset</button>
          <button onClick={handleSave}>Zapisz</button>
        </div>
        <p>Historia pomiarów: </p>
        {laps.length === 0 ? (<p>Brak zapisanych pomiarów</p>
        ) : (
        <ul>
            {laps.map((lap, i) =>{
                
            return(
                    <li key={i}>
                        {i + 1}. {format(lap)}
                        <button onClick={()=> handleDelete(i)}>Usuń</button>
                    </li>
                
            )})}
        </ul>)}
        
      </div>
    );
}
export default Timer;