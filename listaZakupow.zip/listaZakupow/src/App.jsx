import React, { useState } from "react";
import ShoppingItem from "./ShoppingItem.jsx"
function App() {
  const [shoppingList, setShoppingList] = useState([
    { id: 1, name: "Mleko", quantity: 2, bought: false },
    { id: 2, name: "Chleb", quantity: 1, bought: true },
    { id: 3, name: "Jajka", quantity: 12, bought: false },
    { id: 4, name: "Masło", quantity: 1, bought: false },
  ]);

  function toggleShoppingItem(id) {
    setShoppingList(
      shoppingList.map(item =>
        item.id === id ? { ...item, bought: !item.bought } : item
      )
    );
  }

  function deleteShoppingItem(id) {
    setShoppingList(shoppingList.filter(item => item.id !== id));
  }

  function editQuantity(id, newQuantity) {
    setShoppingList(
      shoppingList.map(item =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
  }

  return (
    <div>
      <h1>Lista zakupów</h1>
      {shoppingList.map(item => (
        <ShoppingItem
          key={item.id}
          item={item}
          onToggle={toggleShoppingItem}
          onDelete={deleteShoppingItem}
          onEditQuantity={editQuantity}
        />
      ))}
    </div>
  );
}

export default App;
