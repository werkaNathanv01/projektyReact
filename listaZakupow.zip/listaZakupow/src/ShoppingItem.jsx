function ShoppingItem({ item, onToggle, onDelete, onEditQuantity }) {
  return (
    <div>
      <input
        type="checkbox"
        checked={item.bought}
        onChange={() => onToggle(item.id)}
      />

      <span>
        {item.name} - ilość: {item.quantity}
      </span>

      <button onClick={() => onEditQuantity(item.id, item.quantity + 1)}>+</button>
      <button
        onClick={() =>
          onEditQuantity(item.id, Math.max(1, item.quantity - 1))
        }
      >
        -
      </button>

      <button onClick={() => onDelete(item.id)}>Usuń</button>
    </div>
  );
}

export default ShoppingItem;
