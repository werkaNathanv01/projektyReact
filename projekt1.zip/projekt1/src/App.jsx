import React, { useState } from "react";
import "./index.css";

function App() {
  const [quotes, setQuotes] = useState([
    "Nigdy się nie poddawaj!",
    "Działaj, a nie czekaj.",
    "Każdy dzień to nowa szansa."
  ]);
  const [newQuote, setNewQuote] = useState("");
  const [quoteOfTheDay, setQuoteOfTheDay] = useState("");

  const showRandomQuote = () => {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    setQuoteOfTheDay(quotes[randomIndex]);
  };

  const addQuote = () => {
    if (newQuote.trim()) {
      setQuotes([...quotes, newQuote]);
      setNewQuote("");
    }
  };

  return (
    <div className="center-screen">
      <div className="card">
        <h2 style={{ color: "#007bff", marginBottom: "1.5rem" }}>Generator Cytatów Motywacyjnych</h2>

        <button className="btn-main" onClick={showRandomQuote}>
          Pokaż cytat dnia
        </button>

        {quoteOfTheDay && <p className="lead" style={{ marginBottom: "1rem" }}>{quoteOfTheDay}</p>}

        <div className="input-group">
          <input
            type="text"
            placeholder="Wpisz swój cytat..."
            value={newQuote}
            onChange={(e) => setNewQuote(e.target.value)}
          />
          <button onClick={addQuote}>
            Dodaj
          </button>
        </div>

        <p style={{ marginTop: "1rem" }}>Dostępnych cytatów: {quotes.length}</p>
      </div>
    </div>
  );
}

export default App;